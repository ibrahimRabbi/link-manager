// const linkIcon = `<svg aria-hidden="true" height="27" viewBox="4 4 16 16" version="1.1" width="24" data-view-component="true" class="octicon octicon-code UnderlineNav-octicon d-none d-sm-inline"><path fill="#505f79" fill-rule="evenodd" d="M11 17H7Q4.925 17 3.463 15.537Q2 14.075 2 12Q2 9.925 3.463 8.462Q4.925 7 7 7H11V9H7Q5.75 9 4.875 9.875Q4 10.75 4 12Q4 13.25 4.875 14.125Q5.75 15 7 15H11ZM8 13V11H16V13ZM13 17V15H17Q18.25 15 19.125 14.125Q20 13.25 20 12Q20 10.75 19.125 9.875Q18.25 9 17 9H13V7H17Q19.075 7 20.538 8.462Q22 9.925 22 12Q22 14.075 20.538 15.537Q19.075 17 17 17Z"/></svg>`;

const linkIcon = `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="30" height="27" viewBox="0 0 200 120">

<path fill="#505f79" id="Línea_1_copia" data-name="Línea 1 copia" d="M114.982,76.233l31.687-31.989Z"/>
<path fill="#505f79" id="Elipse_1" data-name="Elipse 1" d="M37,29A19.755,19.755,0,0,1,57,48.5,19.755,19.755,0,0,1,37,68,19.755,19.755,0,0,1,17,48.5,19.755,19.755,0,0,1,37,29Z"/>
<path fill="#505f79" id="Elipse_2" data-name="Elipse 2" d="M98.5,64c11.322,0,20.5,8.507,20.5,19s-9.178,19-20.5,19S78,93.493,78,83,87.178,64,98.5,64Z"/>
<path fill="#505f79" id="Elipse_3" data-name="Elipse 3"d="M157.5,7C172.136,7,184,17.745,184,31s-11.864,24-26.5,24S131,44.255,131,31,142.864,7,157.5,7Z"/>
<text id="W" class="cls-3" x="23.75" y="59.5">W</text>
<text id="B" class="cls-3" x="90.75" y="92.5">B</text>
<text id="E" class="cls-3" x="149.75" y="38.5">E</text>
</svg>`;