const WEB_URL = "https://lm-dev.koneksys.com";
// const WEB_URL = 'http://localhost:5173';

let dialog = document.createElement("dialog");
document.body.appendChild(dialog);

const closeDialog = () => {
  dialog.close();
  document.body.classList.remove("blur-background");
};

function openDialogOSLC(sources) {
  if (dialog.open) {
    dialog.close();
  } else {
    document.body.classList.add("blur-background");
  }
  console.log("Sources: ", sources);

  const type = sources?.sourceType?.toLowerCase();
  let sourceType = "";

  if (type === "task" || type === "subtask") {
    sourceType = "http://open-services.net/ns/cm#Task";
  } else if (type === "epic") {
    sourceType = "http://open-services.net/ns/rm#RequirementCollection";
  } else if (type === "story") {
    sourceType = "http://open-services.net/ns/rm#Requirement";
  } else if (type === "bug") {
    sourceType = "http://open-services.net/ns/cm#Defect";
  } else {
    sourceType = "http://open-services.net/ns/cm#Enhancement";
  }

  const encodedUri = encodeURIComponent(sources?.uri);
  const encodedSourceType = encodeURIComponent(sourceType);
  const appName = "jira";

  dialog.innerHTML = `
  <div id="oslc-modal" class="main-div" >
      <header class="header-div">
         <h2 class="header-title">TraceLynx<h2>
         <div id="oslc-modal-close" class="close-button">
         <span class="close-icon"></span>
       </div>                
      </header>

        <div id="div-frame-container" class="iframe-div">
          <iframe frameBorder="0"
           src="${WEB_URL}/wbe?sourceType=${encodedSourceType}&resourceTypeLabel=${sources?.sourceType}&title=${sources?.title}&titleLabel=${sources?.id}&project=${sources.projectName}&uri=${encodedUri}&origin=${sources.origin}&appName=${appName}&id=${sources?.id}" class="iframe-target-app"></iframe>
        </div>
  </div>`;

  dialog.id = "myDialog";
  document
    .getElementById("oslc-modal-close")
    .addEventListener("click", closeDialog, false);
  dialog.showModal();
}
