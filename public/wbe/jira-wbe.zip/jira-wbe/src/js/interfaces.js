let dialog = document.createElement("dialog");
document.body.appendChild(dialog);

const closeDialog = () => {
  dialog.close();
  document.body.classList.remove("blur-background");
};

function openDialogOSLC(source) {
  if (dialog.open) {
    dialog.close();
  } else {
    document.body.classList.add("blur-background");
  }
  console.log(
    "sourceType: " +
      source?.sourceType +
      "\ntitle: " +
      source?.title +
      "\ntitleLabel: " +
      source?.titleLabel +
      "\nproject: " +
      source.projectName +
      "\nuri: " +
      source?.uri +
      "\norigin: " +
      source.origin +
      "\nappName: " +
      source?.appName +
      "\nid: " +
      source?.id
  );

  dialog.innerHTML = `
  <div id="oslc-modal" class="main-div" >
      <header class="header-div">
         <h2 class="header-title">TraceLynx<h2>
         <div id="oslc-modal-close" class="close-button">
         <span class="close-icon"></span>
       </div>                
      </header>

        <div id="div-frame-container" class="iframe-div">
          <iframe frameBorder="0"
           src="https://lm-dev.koneksys.com/wbe?sourceType=${source?.sourceType}&title=${source?.title}&titleLabel=${source?.id}&project=${source.projectName}&uri=${source?.uri}&origin=${source.origin}&appName=${source?.appName}&id=${source?.id}" class="iframe-target-app"></iframe>
        </div>
  </div>`;

  dialog.id = "myDialog";
  document
    .getElementById("oslc-modal-close")
    .addEventListener("click", closeDialog, false);
  dialog.showModal();
}
