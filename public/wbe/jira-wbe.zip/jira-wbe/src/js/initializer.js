//#region - Initializers
MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
//#endregion - Initializers

//#region - Mutation Observer
const observer = new MutationObserver(function () {
  //#region - Issue Header

  const origin = window.location.origin;
  const container = document.getElementsByClassName('_otyr1b66 _1yt4swc3 _1e0c116y');

  Array.from(container)?.forEach((element) => {
    if (!element.classList.contains('injected')) {
      const baseURI = element?.baseURI;
      element.classList.add('injected');
      let div = document.createElement('div');
      let span = document.createElement('span');
      let btn = document.createElement('button');
      div.setAttribute('role', 'presentation')
      span.className = '_1e0c1txw _2hwxu2gc'
      btn.className = 'btn-wbe';
      btn.innerHTML = icon; //This is a svg defined in linkIcon.js
      div.appendChild(btn);
      span.appendChild(div);
      element.insertBefore(span, element.lastElementChild);

      const r = document.getElementsByClassName('css-1gd7hga');//Getting the class that contains the title and uri
      const title = document.getElementsByClassName('_1e0c1txw _vwz4kb7n _p12f1osq _1nmz1hna _ca0qi2wt _n3tdi2wt _kqswh2mm _1ltvi2wt');
      const typeImgTag = document.querySelector('[data-testid="issue.views.issue-base.foundation.change-issue-type.tooltip--container"]')?.querySelector('img');// Get the source type 
      btn.addEventListener("click",
        function () {

          //Geeting the resource info
          let url = window.location.href;
          let regex = /selectedIssue=([^&]+)/
          let issue = url.match(regex);
          let obtained_source_type = typeImgTag?.alt;
          let obtained_label = url.split('=')[1] === undefined ? url.substring(url.lastIndexOf("/") + 1) : url.substring(url.lastIndexOf("=") + 1);
          let obtained_id = issue ? issue[1] : '';
          let obtained_title = title[0]?.textContent;
          let obtained_project_name = r[2]?.outerText;
          let obtained_base_uri = baseURI;
          let obtained_origin = origin;
          let obtained_uri = origin + "/browse/" + obtained_id;

          openDialogOSLC({
            sourceType: obtained_source_type ? obtained_source_type : '',
            titleLabel: obtained_label ? obtained_label : '',
            id: obtained_id ? obtained_id : '',
            title: obtained_title ? obtained_title : '',
            projectName: obtained_project_name ? obtained_project_name : '',
            baseURI: obtained_base_uri ? obtained_base_uri : '',
            uri: obtained_uri ? obtained_uri : '',
            origin: obtained_origin ? obtained_origin : '',
          })
        }
      );
    }
  });


  const projectActions = document.getElementsByClassName('css-8pvvsq');
  if (projectActions[0]?.baseURI != undefined) {
    if (projectActions[0]?.baseURI?.includes("/boards/") && projectActions[0]?.baseURI?.includes("/software/projects/")) {
      Array.from(projectActions)?.forEach((element) => {
        if (!element.classList.contains('injected')) {
          element.classList.add('injected');
          let div = document.createElement('div');
          let span = document.createElement('span');
          let btn = document.createElement('button');
          div.className = "container-div";
          btn.className = "btn-wbe";
          btn.innerHTML = icon; //This is a svg defined in icon.js
          span.appendChild(btn)
          div.appendChild(span);
          element.appendChild(span);

          const baseURI = element?.baseURI;
          const spanTitle = document?.getElementsByClassName("css-1hl287g");
          const title = spanTitle[1]?.getElementsByClassName("css-1gd7hga");
          const projectId = baseURI?.split('/')[baseURI?.split('/').length - 3];

          btn.addEventListener("click",
            function () {
              openDialogOSLC({
                sourceType: "Project",
                titleLabel: projectId,
                id: projectId,
                title: title[0]?.textContent,
                projectName: '-',
                baseURI: baseURI,
                uri: baseURI,
                origin: origin,
                appName: "jira-projects"
              })
            }
          );
        }
      });
    }
  }
});

// define what element should be observed by the observer
// and what types of mutations trigger the callback
observer.observe(document, {
  subtree: true,
  attributes: true,
});
