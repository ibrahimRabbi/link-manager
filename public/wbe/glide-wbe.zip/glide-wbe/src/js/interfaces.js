const WEB_URL = "https://lm-dev.koneksys.com";
// const WEB_URL = 'http://localhost:5173';

let dialog = document.createElement("dialog");

const closeDialog = () => {
  dialog.close();
  document.body.classList.remove("blur-background");
};

function openDialogOSLC(sources) {
  if (dialog.open) {
    dialog.close();
  } else {
    document.body.classList.add("blur-background");
  }

  let sourceType = "";
  const type = sources?.sourceType;
  if (
    type === "PhysicalParts" ||
    type === "DevPartMaster" ||
    type.toLowerCase().includes("part")
  ) {
    sourceType = "http://open-services.net/ns/plm#PhysicalPart";
  } else if (type === "Issue") {
    sourceType = "http://open-services.net/ns/cm#Defect";
  } else if (
    type === "Document" ||
    type?.toLowerCase()?.includes("cad") ||
    type === "Specification"
  ) {
    sourceType = "http://open-services.net/ns/plm#Document";
  } else if (type === "ChangeRequest") {
    sourceType = "http://open-services.net/ns/cm#ChangeRequest";
  } else if (type === "ChangeOrder") {
    sourceType = "http://open-services.net/ns/cm#ChangeRequest";
  } else {
    sourceType = `http://open-services.net/ns/plm#PhysicalPart`;
  }

  const appName = "glideyoke";
  const encodedUri = sources?.uri ? encodeURIComponent(sources?.uri) : "";
  sourceType = encodeURIComponent(sourceType);

  dialog.innerHTML = `
    <div id="oslc-modal" class="main-div" >
       <header class="header-div">
          <h2 class="header-title"><span style="color:#2c74b3;">Trace</span><span style="color:#144272;">Lynx</span><h2>
          <div id="oslc-modal-close" class="close-button">
            <span class="close-icon"></span>
          </div>                 
       </header>

        <div id="div-frame-container" class="iframe-div">
        <iframe frameBorder="0"
        src="${WEB_URL}/wbe?sourceType=${sourceType}&resourceTypeLabel=${type}&project=${sources?.project}&title=${sources?.title}&uri=${encodedUri}&commit=be6c5659&branch=${sources?.title}&origin=${sources?.origin}&appName=${appName}" class="iframe-target-app"></iframe>
        </div>
  </div>`;

  document.body.appendChild(dialog);
  dialog.id = "myDialog";
  dialog.showModal();
  document
    .getElementById("oslc-modal-close")
    ?.addEventListener("click", closeDialog, false);
}
