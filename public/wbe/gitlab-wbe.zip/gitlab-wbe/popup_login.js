const loginElements = `
    <form class="form-container" id="login-form-main">
        <p class="loading_tag" style="">Loading...</p>
        <input type="text" placeholder="Email address or phone number" id="user-name" required>
        <input type="password" placeholder="Password" id="user-password" required>
        <button type="submit" class="btn-form">Login</button>
    </form>
`
const logoutElements = `
        <div class="form-container">
            <div class="user_container">
                <img class="avatar" src="https://cdn.vectorstock.com/i/preview-1x/99/94/default-avatar-placeholder-profile-icon-male-vector-23889994.jpg" alt="user">
                <div class="user_details">
                    <h5 class="user_name"></h5>
                    <p class="user_email"></p>
                </div>
            </div>
            <button class="btn-form" id="logout-btn">Logout</button>
        </div>
`;

// get user name and password from the popup_login.html file
const login_container = document.querySelector('[class="login-form"]');

function setPopupHtml() {
    let tokenObj = { token: '' }
    let user = localStorage.getItem('lm_user');
    
    if (user) {
        try{
            tokenObj['token'] = JSON.parse(user)
        }
        catch(err){
            tokenObj["token"]=undefined;
        }
    }
    const userData = tokenObj.token;
    if (userData) {
        // display user info if user logged in
        login_container.innerHTML = logoutElements
        const decodedToken = decode_jwt(userData?.access_token)
        if (userData?.access_token) {
            const userName = document.querySelector('.user_name');
            const userEmail = document.querySelector('.user_email')
            userName.textContent = decodedToken?.name;
            userEmail.textContent = decodedToken?.email

        }
        const logoutBtn = document.getElementById('logout-btn')
        logoutBtn?.addEventListener('click', () => { logoutAlert() })

        // check is the token valid
        chrome.runtime.sendMessage({
            message: "is-valid-token",
            payload: tokenObj.token?.access_token
        }, response => {
            if (response.message === 'valid-token') {
                console.log('Valid token')
                chrome.storage.local.set({'lm_user': tokenObj.token?.access_token});
            }
            else if (response.message === 'invalid-token') {
                console.log('Invalid token')
                localStorage.removeItem('lm_user')
                removeItem();
                setPopupHtml()
            }
        });
    }

    else {
        // display login form if user not logged in
        login_container.innerHTML = loginElements
        const login_form = document.getElementById('login-form-main')
        const loading_tag = document.querySelector('.loading_tag')
        loading_tag.style.display = 'none';

        // handle login submit controller
        login_form.addEventListener('submit', (e) => {
            const loading = document.querySelector('.loading_tag')
            e.preventDefault();
            loading.style.display = 'block';
            const userNameValue = document.querySelector('#user-name')
            const passwordValue = document.querySelector('#user-password')
            chrome.runtime.sendMessage({
                message: "login",
                payload: { username: userNameValue?.value, password: passwordValue?.value }
            }, response => {
                loading.style.display = 'none';
                if (response.message === 'login-success') {
                    console.log(response.user?.user)
                    localStorage.setItem('lm_user', JSON.stringify(response.user?.user));
                    setPopupHtml()
                } else if (response.message === 'login-failed') {
                    localStorage.removeItem('lm_user')
                    removeItem()
                    setPopupHtml()
                }
            });
        })
    }
}
// call set html function
setPopupHtml()
// logout alert popup
function logoutAlert() {
    let text = "Are you sure you want to logout!!";
    if (confirm(text) == true) {
        localStorage.removeItem('lm_user')
        removeItem()
        setPopupHtml()
    }
}

// Decode JWT token 
function decode_jwt(token) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function (c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
    return JSON.parse(jsonPayload);
}

function removeItem(){
    chrome.storage.local.clear(function() {
        var error = chrome.runtime.lastError;
        if (error) {
            console.error(error);
        }
        // do something more
    });
    chrome.storage.sync.clear();
}