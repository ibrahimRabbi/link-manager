
try {
    importScripts("background.js");
} catch (e) {
    console.log(e);
}