const API_URL = "https://lm-api-dev.koneksys.com/api/v1";
// const API_URL = "http://localhost:5002/api/v1";

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  // check is the token is valid or invalid
  if (request.message === "is-valid-token") {
    isAuthenticated(request.payload)
      .then((res) => {
        if (res) {
          sendResponse({ message: "valid-token", token:request.payload });
        } else {
          sendResponse({ message: "invalid-token" });
        }
      })
  }

  // login controller
  if (request.message === "login") {
    const credentials = `${request.payload.username}:${request.payload.password}`;
    const header = { 'Authorization': 'Basic ' + btoa(credentials) }
    getUser(header)
      .then((user) => {
        if (user === 'fail') sendResponse({ message: "login-failed" });
        else {
          //localStorage.setItem('lm_user', user);
          sendResponse({ message: "login-success", user: user });
        }
      })
      .catch((error) => {
        sendResponse({ message: "login-failed" });
      });
  }
  return true;
});

// handle login
function getUser(header) {
  const API_LOGIN_URL = `${API_URL}/auth/login`;
  let user = {};
  return fetch(`${API_LOGIN_URL}`, {
    method: 'POST',
    headers: header
  })
    .then(res => {
      return new Promise(async resolve => {
        if (res.status !== 200) {
          resolve('fail')
        } else {
          const data = await res.json();
          console.log("data", data);
          user["user"] = data;
          resolve(user)
        }
      })
    })
    .catch(err => console.log(err));
}

// get user
function isAuthenticated(token) {
  console.log(token)
  if (token) {
    let url = `${API_URL}/user?page=1&per_page=5`;
    return fetch(url, {
      method: "GET",
      headers: {
        'Content-Type': 'application/json',
        Authorization: "Bearer " + token,
      },
    })
      .then(res => {
        return new Promise(resolve => {
          if (res.status === 200 || res.status === 204) {
            return resolve(true)
          }
          return resolve(false)
        })
      })
      .catch(err => console.log(err));
  } else {
    return false;
  }
}
