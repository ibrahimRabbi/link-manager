let dialog = document.createElement("dialog");
document.body.appendChild(dialog);

function closeDialog() {
  dialog.close();
  document.body.classList.remove("blur-background");
  dialog.innerHTML = "";
  const wbeBtnContainer = document.getElementById("floating-button-wbe");
  if (wbeBtnContainer != null || wbeBtnContainer != undefined) {
    document.body.removeChild(wbeBtnContainer);
  }
}

// mix panel
let mixpanel_script = document.createElement("script");
mixpanel_script.async = true;
mixpanel_script.src =
  "https://unpkg.com/mixpanel-browser@2.43.0/dist/mixpanel.cjs.js";
document.head.appendChild(mixpanel_script);

function openDialogOSLC(sources) {
  if (dialog.open) {
    dialog.close();
  }
  document.body.classList.add("blur-background");
  // get data from gitlab
  const branchName = document
    .querySelector(".tree-ref-container")
    ?.querySelector(".gl-new-dropdown-button-text")
    ?.textContent?.trim();
  const commit = document
    .querySelector(".blob-commit-info")
    ?.querySelector('[class="label label-monospace monospace"]')
    ?.textContent?.trim();
  const origin = window.location.origin;

  dialog.innerHTML = `
    <div id="oslc-modal" class="main-div" >
        <header class="header-div">
            <h2 class="header-title">TraceLynx<h2>
            <div id="oslc-modal-close" class="close-button">
  <span class="close-icon"></span>
</div>
                
        </header>

        <div id="div-frame-container" class="iframe-div">
        <iframe frameBorder="0"
         src="https://lm-dev.koneksys.com/wbe?sourceType=${
           sources?.sourceType
         }&project=${sources?.project}&title=${sources?.title}&uri=${
    sources?.uri
  }&commit=${
    commit ? commit : sources?.commitId
  }&branch=${branchName}&origin=${origin}&appName=${"gitlab"}&logoUrl=https://i.ibb.co/PZj4TRb/gitlab-logo.png"
         class="iframe-target-app">
          </iframe>
        </div>   
  </div>`;
  dialog.id = "myDialog";
  dialog.showModal();
  document
    .getElementById("oslc-modal-close")
    ?.addEventListener("click", closeDialog, false);
}
