const WEBAPP_URL = "https://lm-dev.koneksys.com";
// const WEBAPP_URL = "http://localhost:5173";

let dialog = document.createElement("dialog");
document.body.appendChild(dialog);

function closeDialog() {
  dialog.close();
  document.body.classList.remove("blur-background");
  dialog.innerHTML = "";
  const wbeBtnContainer = document.getElementById("floating-button-wbe");
  if (wbeBtnContainer != null || wbeBtnContainer != undefined) {
    document.body.removeChild(wbeBtnContainer);
  }
}

function openDialogOSLC(sources) {
  console.log('Sources: ', sources)
  if (dialog.open) {
    dialog.close();
  }
  document.body.classList.add("blur-background");

  const projectId = document.querySelector('[data-project-id]')?.getAttribute('data-project-id');
  const branchNameElement = document.querySelector(".tree-ref-container")?.querySelector(".gl-new-dropdown-button-text")
  const getCommitText = document.querySelector(".commit-actions")?.querySelectorAll('.label-monospace');
  const getCommitText2 = document.querySelector('.commit-actions')?.querySelector(".gl-button-text");

  const branchName = branchNameElement?.textContent?.trim();
  const getCommitId = getCommitText[1]?.textContent?.trim()
  const getCommitId2 = getCommitText2?.textContent?.trim()
  const commit = getCommitId || getCommitId2;
  const parentFileUri = sources?.parentUri ? sources?.parentUri : '';
  const logoUrl = 'https://i.ibb.co/PZj4TRb/gitlab-logo.png';

  dialog.innerHTML = `
    <div id="oslc-modal" class="main-div" >
        <header class="header-div">
            <h2 class="header-title">TraceLynx<h2>
            <div id="oslc-modal-close" class="close-button">
              <span class="close-icon"></span>
            </div>                
        </header>

        <div id="div-frame-container" class="iframe-div">
          <iframe frameBorder="0"
              src="${WEBAPP_URL}/wbe?project=${sources?.project ? sources?.project : ''}&title=${sources?.title ? sources?.title : ''}&uri=${sources?.uri ? sources?.uri : ''}&parentFileUri=${parentFileUri ? parentFileUri : ''}&commit=${commit || sources?.commitId}&branch=${branchName || sources?.branchName}&appName=gitlab&searchParams=${sources?.searchParams ? sources?.searchParams : ''}&logoUrl=${logoUrl}&projectId=${projectId ? projectId : ''}&sourceType=${sources?.sourceType ? sources?.sourceType : ''}&parentSourceType=${sources?.parentSourceType ? sources?.parentSourceType : ''}" class="iframe-target-app">
          </iframe>
        </div>   
  </div>`;
  dialog.id = "myDialog";
  document
    .getElementById("oslc-modal-close")
    ?.addEventListener("click", closeDialog, false);
  dialog.showModal();
}
