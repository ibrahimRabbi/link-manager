const WEBAPP_URL = "https://lm-dev.koneksys.com";
// const WEBAPP_URL = "http://localhost:5173";

let dialog = document.createElement("dialog");
document.body.appendChild(dialog);

function closeDialog() {
  dialog.close();
  document.body.classList.remove("blur-background");
  dialog.innerHTML = "";
  const wbeBtnContainer = document.getElementById("floating-button-wbe");
  if (wbeBtnContainer != null || wbeBtnContainer != undefined) {
    document.body.removeChild(wbeBtnContainer);
  }
}

function openDialogOSLC(sources) {
  if (dialog.open) {
    dialog.close();
  }
  document.body.classList.add("blur-background");
  // get data from gitlab
  const branchName = document
    .querySelector(".tree-ref-container")
    ?.querySelector(".gl-new-dropdown-button-text")
    ?.textContent?.trim();
  const commit = document
    .querySelector(".blob-commit-info")
    ?.querySelector('[class="label label-monospace monospace"]')
    ?.textContent?.trim();
  const origin = window.location.origin;
  console.log("Dialog\nSource type: " + sources?.sourceType
    + "\nTitle: " + sources?.title
    + "\nProject: " + sources?.project
    + "\nUri: " + sources?.uri
    + "\nOrigin: " + window.location.origin
    + "\nAppName: " + "gitlab \n\n"
    + "\nCommit: " + commit
    + "\nBranch: " + branchName);
  dialog.innerHTML = `
    <div id="oslc-modal" class="main-div" >
        <header class="header-div">
            <h2 class="header-title">TraceLynx<h2>
            <div id="oslc-modal-close" class="close-button">
              <span class="close-icon"></span>
            </div>                
        </header>

        <div id="div-frame-container" class="iframe-div">
          <iframe frameBorder="0"
              src="${WEBAPP_URL}/wbe?sourceType=${sources?.sourceType}&project=${sources?.project}&title=${sources?.title}&uri=${sources?.uri}&commit=${commit ? commit : sources?.commitId}&branch=${branchName}&origin=${origin}&appName=${sources?.appName}&logoUrl=https://i.ibb.co/PZj4TRb/gitlab-logo.png&searchParams=${sources?.searchParams}" class="iframe-target-app">
          </iframe>
        </div>   
  </div>`;
  dialog.id = "myDialog";
  document
    .getElementById("oslc-modal-close")
    ?.addEventListener("click", closeDialog, false);
  dialog.showModal();
}
