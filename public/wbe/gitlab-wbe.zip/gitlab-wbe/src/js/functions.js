const API_URL = "https://lm-api-dev.koneksys.com/api/v1";
// const API_URL = "http://localhost:5002/api/v1";

function handleBlockOfCodeSelection(elements, selection){
    let selectedElements = [];
    for (let i = 0; i < elements.length; i++) {
        if (elements[i].contains(selection.anchorNode) || elements[i].contains(selection.focusNode)) {  //Anchor node ==start line ,   focus node ==end line
            selectedElements.push(elements[i]);
        }
    }
    if (selectedElements !== null) {
        let projectName = document.getElementsByClassName("gl-truncate-end")[0]?.innerText;
        let lines_content = "";
        let start_line = parseInt(selectedElements[0].id.split("LC")[1]);
        let end_line = null;
        let selectedUri = window.location.href;
        const uri= new URL(selectedUri);
        selectedUri =uri.protocol+"//"+uri.host+uri.pathname;
        let search_params = uri.search;
        if (selectedElements[1] !== undefined) {
            end_line = parseInt(selectedElements[1].id.split("LC")[1]);
        }
        if (end_line != null) {
            for (let k = start_line; k <= end_line; k++) {
                let item = document.getElementById("LC" + k);
                //item.style.backgroundColor = "#abf5d1";
                lines_content += item.textContent + "\n";
            }
            selectedUri = selectedUri + "%23" + "L" + start_line + "-" + end_line;
        }
        else {
            let item = document.getElementById("LC" + start_line);
            lines_content += item.textContent + "\n";
            selectedUri = selectedUri + "%23" + "L" + start_line;
        }
        const titleArray = selectedUri?.split('/');
        let title = titleArray[titleArray?.length - 1];
        title = title.replace("#", "%23")
        console.log("Source type: RepositoryFileBlockOfCodeSelection"
        + "\nTitle: " + title
        + "\nProject: " + projectName
        + "\nUri: " + selectedUri
        + "\nOrigin: " + window.location.origin
        + "\nContent: " + lines_content
        + "\nAppName: " + "gitlab"
        + "\nSearch_params: "+search_params);
        openDialogOSLC({
            sourceType: 'RepositoryFileBlockOfCodeSelection',
            title: title,
            uri: selectedUri,
            content: lines_content,
            project: projectName,
            appName: "gitlab",
            searchParams: search_params
        })
    }
}

function handleFileSelection(){
    let projectName = document.getElementsByClassName("gl-truncate-end")[0]?.innerText;
    let selectedUri = window.location.href;
    const titleArray = selectedUri?.split('/');
    let title = titleArray[titleArray?.length - 1];
    const uri= new URL(selectedUri);
    selectedUri =uri.protocol+"//"+uri.host+uri.pathname;
    let search_params = uri.search;
    console.log("Source type: RepositoryFile"
        + "\nTitle: " + title
        + "\nProject: " + projectName
        + "\nUri: " + selectedUri
        + "\nOrigin: " + window.location.origin
        + "\nAppName: " + "gitlab"
        + "\nSearch_params: "+search_params);
    openDialogOSLC({
        uri: selectedUri,
        title: title,
        sourceType: 'RepositoryFile',
        project: projectName,
        origin: window.location.origin,
        appName: "gitlab",
        searchParams: search_params
    })
}

async function getLinksCreatedInFile(resource_id){
    let items=[];
    let lm_token;
    chrome.storage.local.get('lm_user', async function(result){
        lm_token =result.lm_user;
        if (lm_token !== null || lm_token !== undefined) {
            let url = `${API_URL}/link/code-blocks?resource_id=${resource_id}`;
            const response =await fetch(url, {
                method: 'GET',
                headers: { 'Authorization': 'Bearer '+ lm_token}
            })

            if (response.status===200) {
                const data= await response.json();
                items=data["data"];
                let link_number=0;
                let trasparency=1.0;
                const links = [];
                items.forEach(item => {
                    if(item["id"].includes("#")){
                        let selected_lines= item["id"].split("#")[1];
                        if(selected_lines.includes("L")){
                            selected_lines=selected_lines.replace("L", "");
                        }
                        link_number++;
                        let lines, start, end;
                        if(selected_lines.includes("-")){
                            lines=selected_lines.split("-");
                            start=parseInt(lines[0]);
                            end=parseInt(lines[1]);
                        }else{
                            start=parseInt(selected_lines);
                            end=parseInt(selected_lines);
                        }
                        trasparency = trasparency-0.1;
                        for (let k = start; k <= end; k++) {
                            const link_info = {
                                id: link_number,
                                line: "LC"+k,
                                background: trasparency
                            };
                            links.push(link_info)
                        }
                    }
                });

                links.forEach(async link => {
                    let element = await waitForElementToBePresent(link.line);
                    if(element!==null || element!==undefined){
                        if (!element.classList.contains('link-'+link.id)) {
                            element.classList.add('link-'+link.id);
                            element.style.backgroundColor = 'rgba(190, 225, 253, '+link.background+')';
                        }
                    }
                });
            } else {
                console.log("No links available");
            }
        }
    });
}

async function waitForElementToBePresent(elementId) {
    return new Promise((resolve, reject) => {
        const interval = setInterval(() => {
            const element = document.getElementById(elementId);
            if (element) {
                clearInterval(interval);
                resolve(element);
            }
        }, 100); // Check every 100 milliseconds
    });
}
async function getToken(){
    let token;
    chrome.storage.local.get('lm_user', function(result){
        console.log(result)
        token =result.lm_user;
        console.log(token)
    });
    return token;
}
