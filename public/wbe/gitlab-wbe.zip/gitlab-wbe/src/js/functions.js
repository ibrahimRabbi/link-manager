function handleBlockOfCodeSelection(elements, selection){
    let selectedElements = [];
    for (let i = 0; i < elements.length; i++) {
        if (elements[i].contains(selection.anchorNode) || elements[i].contains(selection.focusNode)) {  //Anchor node ==start line ,   focus node ==end line           
            selectedElements.push(elements[i]);
        }
    }
    if (selectedElements !== null) {
        let projectName = document.getElementsByClassName("gl-truncate-end")[0]?.innerText;
        let lines_content = "";
        let start_line = selectedElements[0].id.split("LC")[1];
        let end_line = null;
        let selectedUri = window.location.href;
        if (selectedUri.includes("#")) {
            selectedUri = selectedUri.split("#")[0];
        }
        if (selectedElements[1] != undefined) {
            end_line = selectedElements[1].id.split("LC")[1];
        }
        if (end_line != null) {
            for (let k = start_line; k <= end_line; k++) {
                let item = document.getElementById("LC" + k);
                //item.style.backgroundColor = "#abf5d1";
                lines_content += item.textContent + "\n";
            }
            selectedUri = selectedUri + "%23" + "L" + start_line + "-" + end_line;
        }
        else {
            let item = document.getElementById("LC" + start_line);
            lines_content += item.textContent + "\n";
            selectedUri = selectedUri + "%23" + "L" + start_line;
        }
        const titleArray = selectedUri?.split('/');
        const title = titleArray[titleArray?.length - 1]
        console.log("Source type: Block-of-code-selection"
        + "\nTitle: " + title?.toString()
        + "\nProject: " + projectName
        + "\nUri: " + selectedUri
        + "\nOrigin: " + window.location.origin
        + "\nContent: " + lines_content
        + "\nAppName: " + "gitlab \n\n");
        openDialogOSLC({
            uri: selectedUri,
            title: title?.toString(),
            sourceType: 'Block-of-code-selection',
            content: lines_content,
            project: projectName
        })
    }
}

function handleFileSelection(){
    let projectName = document.getElementsByClassName("gl-truncate-end")[0]?.innerText;
    let selectedUri = window.location.href;
    const titleArray = selectedUri?.split('/');
    const title = titleArray[titleArray?.length - 1];
    console.log("Source type: File"
        + "\nTitle: " + title?.toString()
        + "\nProject: " + projectName
        + "\nUri: " + selectedUri
        + "\nOrigin: " + window.location.origin
        + "\nAppName: " + "gitlab \n\n");
    openDialogOSLC({
        uri: selectedUri,
        title: title?.toString(),
        sourceType: 'File',
        project: projectName, 
        origin: window.location.origin,
        appName: "gitlab",

    })
}


async function getLinksCreatedInFile(resource_id){ 
    let items=[];
    let token = await getToken();
    if(token!=null||token!=undefined){
        let url ='https://lm-api-dev.koneksys.com/api/v1/link/code-blocks?resource_id='+resource_id   
        const response =await fetch(url, {
                method: 'GET',
                headers: { 'Authorization': 'Bearer '+token}
            })
        if(response.status===200){
            const data= await response.json();
            items=data["data"];
            let link_number=0;
            let trasparency=1.0;
            items.forEach(item => {                    
                if(item["resource_type"]==="http://open-services.net/ns/scm#RepositoryFileBlockOfCodeSelection"){   
                    link_number++;                                   
                    let lines= item["selected_lines"];
                    let start = lines.split("-")[0];
                    let end = lines.split("-")[1]; 
                    trasparency = trasparency-0.05;                   
                    for (let k = start; k <= end; k++) {                                            
                        let item = document.getElementById("LC" + k); 
                        if(item!=null||item!=undefined){
                            if (!item.classList.contains('link'+link_number+"-"+lines)) {                            
                                item.classList.add('link'+link_number+"-lines:"+lines);
                                item.style.backgroundColor = 'rgba(190, 225, 253, '+trasparency+')';                                                                                              
                            }          
                        }                                               
                    }
            }
            }); 
        }
        else{
            console.log("No links available");
        }
    }
}

async function getToken(){ 
    const response = await fetch("https://lm-api-dev.koneksys.com/api/v1/auth/login", {
        method: 'POST',
        headers: { 'Authorization': 'Basic bWFyaW86YWRtaW4='}
      })
    if(response.ok){
        const data= await response.json();
        return data["access_token"];
    }
    else{
        return null;
    }

}