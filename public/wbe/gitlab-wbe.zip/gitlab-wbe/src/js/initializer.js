const myObserver = new MutationObserver(function () {

    // Put link icon in file
    var fileListItems = document.getElementsByClassName("tree-item");
    if (fileListItems.length > 0) {
        Array.from(fileListItems).map(el => {
            const isBtn = el.querySelector('button');
            let backBtn = el.textContent;
            if (!isBtn && backBtn !== ' .. ') {
                let projectName = document.getElementsByClassName("gl-truncate-end")[0]?.innerText;
                const aTag = el.querySelector('.tree-item-link')   
                if (aTag?.textContent?.includes('.')) {
                    let span = document.createElement('span');
                    let btn = document.createElement('button');
                    let td = document.createElement('td');
                    btn.className = "btn-wbe";
                    btn.innerHTML = 'Link editor' + icon; //This is a svg defined in icon.js
                    span.appendChild(btn)
                    td.appendChild(span);
                    el.appendChild(td);
                    btn.addEventListener("click",
                        function () {
                            openDialogOSLC({
                                uri: aTag.href,
                                title: aTag.textContent,
                                sourceType: 'File',
                                project: projectName
                            })
                        }
                    );
                    return el;
                }
            }
            else return el
        })
    }

    //var commitListItems = document.getElementsByClassName("js-commits-list-item"); //Get commits lists from github repo
    var commitListItems = document.getElementsByClassName("commit flex-row js-toggle-container");
    if (commitListItems.length > 0) {
        Array.from(commitListItems).forEach((element) => {
            if (!element.classList.contains('injected')) {
                let commitBtnDiv = element.getElementsByClassName("commit-sha-group")[0];//Get Div BtnGroup that contains button to copy full SHA and commit
                let commitId = commitBtnDiv.getElementsByClassName('gl-button')[0].getAttribute("data-clipboard-text");//Get commit like: "be6c5659ba693040f42e3acf3343ce944a3e8d51" 
                element.classList.add('injected');
                let divButton = document.createElement('div');
                let span = document.createElement('span');
                let btn = document.createElement('button');
                divButton.className = "container-div";
                btn.className = "btn-wbe";
                btn.innerHTML = 'Link editor' + icon; //This is a svg defined in icon.js
                span.appendChild(btn)
                divButton.appendChild(span);
                let div = element.getElementsByClassName("label")[0];
                commitBtnDiv.insertBefore(divButton, div);
                const commit = div.innerText;
                btn.addEventListener("click",
                    function () {
                        openDialogOSLC({
                            commit, sourceType: 'Commit',
                            commitId: commitId
                        })
                    }
                );
            }
        });
    }
    //Add floating wbe button in file content view
    let fileHolder= document.getElementById('fileHolder');
    if(fileHolder!=null || fileHolder!=undefined){     
        let resource_id = window.location.href;
        if (resource_id.includes("#")) {
            resource_id = resource_id.split("#")[0];
        }
        if (resource_id.includes("?")) {
            resource_id = resource_id.split("?")[0];
        }
              
        let btnFound = document.getElementById("floating-button-wbe");
        if (btnFound === null || btnFound === undefined) {           
            let btn = document.createElement('button');
            btn.id = "floating-button-wbe";
            btn.innerHTML = icon;
            btn.className = "btn-wbe";
            btn.style.position = "fixed";
            btn.style.bottom = "50px";
            btn.style.right = "50px"
            btn.style.zIndex = "999";
            btn.onclick=function() {handleFileSelection();};
            document.body.appendChild(btn);
            getLinksCreatedInFile(resource_id)
        }
    }else{
        let btnFound = document.getElementById("floating-button-wbe");
        if (btnFound) {   
            document.body.removeChild(btnFound);
        }
    }
    //Event to be executed when a block of code is selected in the file content view
    document.addEventListener('mouseup', function (event) {
		let elements = document.getElementsByClassName('line');
        let selection = window.getSelection();
        let selectedText = selection.toString().trim();
        if (selectedText !== '') {
            let selectedElements = [];
            for (let i = 0; i < elements.length; i++) {
                if (elements[i].contains(selection.anchorNode) || elements[i].contains(selection.focusNode)) {  //Anchor node ==start line ,   focus node ==end line           
                    selectedElements.push(elements[i]);
                }
            }
            if (selectedElements.length > 0) {
                let btnFound = document.getElementById("floating-button-wbe");
                if (btnFound === null || btnFound === undefined) {   
                    let btn = document.createElement('button');
                    btn.id = "floating-button-wbe";
                    btn.innerHTML = icon;
                    btn.className = "btn-wbe";
                    btn.style.position = "fixed";
                    btn.style.bottom = "50px";
                    btn.style.right = "50px"
                    btn.style.zIndex = "999";
                    btn.onclick=function() {handleBlockOfCodeSelection(elements, selection);};
                    document.body.appendChild(btn);
                }else{
                    btnFound.removeAttribute(this.onclick);
                    btnFound.onclick=function() {handleBlockOfCodeSelection(elements, selection);};
                }
            }
            else {
                let btnFound = document.getElementById("floating-button-wbe");
                if (btnFound != null || btnFound != undefined) {
                    document.body.removeChild(btnFound);
                }
            }
        }
    });    

});

myObserver.observe(document, {
    subtree: true,
    attributes: true,
    childList: true
});
