const icon = `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 160 160">
<defs>
  <style>
    .cls-1, .cls-2 {
      fill: #fff;
    }

    .cls-1 {
      fill-rule: evenodd;
    }
  </style>
</defs>
<path class="cls-1" d="M38,85.928L39.979,80,66.016,98.082l-1.974,5.933Z"/>
<path class="cls-1" d="M92.827,104.357L90.69,98.69l28.209-28.6,2.137,5.666Z"/>
<circle id="Ellipse_1_copy_2" data-name="Ellipse 1 copy 2" class="cls-2" cx="23.328" cy="73.359" r="19.984"/>
<path id="Ellipse_1_copy_4" data-name="Ellipse 1 copy 4" class="cls-1" d="M79.985,83.333A20.013,20.013,0,1,1,60,103.346,20,20,0,0,1,79.985,83.333Z"/>
<circle id="Ellipse_1_copy_3" data-name="Ellipse 1 copy 3" class="cls-2" cx="133.297" cy="63.359" r="19.985"/>
</svg>`;
