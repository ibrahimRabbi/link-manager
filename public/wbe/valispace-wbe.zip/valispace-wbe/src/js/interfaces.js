const WEBAPP_URL = "https://lm-dev.koneksys.com";
// const WEBAPP_URL = "http://localhost:5173";

let dialog = document.createElement("dialog");
document.body.appendChild(dialog);
const origin = window.location.origin;

function closeDialog() {
  dialog.close();
  document.body.classList.remove("blur-background");
}

async function openDialogOSLC(sources) {
  if (dialog.open) dialog.close();
  else {
    document.body.classList.add("blur-background");
  }
  const projectName = document
    .querySelector("project span")
    ?.textContent.trim();

  console.log("Unique URI for create the link:> ", sources?.uri);

  let sourceType = "";
  if (sources?.sourceType === "Requirement")
    sourceType = "http://open-services.net/ns/rm#Requirement";
  else if (sources?.sourceType === "Project")
    sourceType = "http://open-services.net/ns/cm#Project";
  else {
    sourceType = `http://open-services.net/ns/cm#${sources?.sourceType}`;
  }

  const appName = "valispace";
  const encodedUri = sources?.uri ? encodeURIComponent(sources?.uri) : "";
  sourceType = encodeURIComponent(sourceType);

  // display traceLynx app conditionally by requirement ID.
  const iframeContainer = {};
  if (
    sources?.sourceType === "Project" ||
    (sources?.sourceType === "Requirement" && sources?.requirementId)
  ) {
    iframeContainer["htmlContent"] = `
        <iframe
          src="${WEBAPP_URL}/wbe?sourceType=${sourceType}&resourceTypeLabel=${sources?.sourceType}&title=${sources?.title}&titleLabel=${sources?.titleLabel}&project=${projectName}&uri=${encodedUri}&origin=${origin}&appName=${appName}"
          class="iframe-target-app"></iframe>
        `;
  } else {
    iframeContainer["htmlContent"] = `
        <div class="popupForId">
        <h2>We are very sorry, you can't create any link without ID.!<h2>
        <p>But in order to open the Tracelynx application you need to enable the ID column of the Valispace requirement table.</p>
        </div>
        `;
  }

  dialog.innerHTML = `
    <div id="oslc-modal" class="main-div" >
       <header class="header-div">
         <h2 class="header-title"><span style="color:#2c74b3;">Trace</span><span style="color:#144272;">Lynx</span><h2>
         <div id="oslc-modal-close" class="close-button">
         <span class="close-icon"></span>
       </div>                
       </header>

        <div id="div-frame-container" class="iframe-div">
         ${iframeContainer?.htmlContent}
        </div>
    </div>`;

  dialog.id = "myDialog";
  dialog.showModal();
  document
    .getElementById("oslc-modal-close")
    ?.addEventListener("click", closeDialog, false);
}
