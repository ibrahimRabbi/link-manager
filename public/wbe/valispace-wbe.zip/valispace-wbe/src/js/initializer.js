MutationObserver = window.MutationObserver || window.WebKitMutationObserver;

const myObserver = new MutationObserver(function () {

    // Create link with valispace requirement
    const tableAcCon = document.querySelectorAll('vs-table-actions')
    if (tableAcCon.length) {
        Array.from(tableAcCon)?.map(actionContainer => {

            const reqBtn = document.createElement('button');
            reqBtn.className="btn-wbe-req";
            
            //reqBtn.className = "mat-focus-indicator mat-icon-button mat-button-base mat-accent ng-star-inserted";
            reqBtn.setAttribute('mat-icon-button', '');
            reqBtn.setAttribute('color', 'accent');
            reqBtn.setAttribute('traceLynxBtn2', '');
            
            reqBtn.innerHTML = `
                <span class="mat-button-wrapper">${icon}</span>
                    <span matripple class="mat-ripple mat-button-ripple mat-button-ripple-round"></span>
                    <span class="mat-button-focus-overlay"></span>
                 `;
            
            const requirementWbeBtn = actionContainer?.querySelector('[traceLynxBtn2]');
            if (!requirementWbeBtn && window.location.pathname?.includes('requirements')) {

                const isLayerIcon = actionContainer?.querySelector('[class="app-icon fa-layer-plus fad icon-layer-plus undefined ng-star-inserted"]');
                const isCopyIcon = actionContainer?.querySelector('[class="app-icon fa-copy fal icon-copy undefined ng-star-inserted"]');

                //if (isCopyIcon || isLayerIcon) {
                    //actionContainer?.insertBefore(reqBtn, actionContainer.firstChild);
                    actionContainer?.appendChild(reqBtn);
                //}

            }

            reqBtn.addEventListener("click",
                function () {
                    // get data from requirement table
                    const rowIndex = reqBtn.parentElement.parentElement.parentElement?.getAttribute('row-index');
                    const dataRow = document.querySelectorAll(`[row-index="${rowIndex}"]`);
                    const identifier = dataRow[0]?.querySelector(`[col-id="identifier"]`)?.innerText;
                    const titleText = dataRow[1]?.querySelector(`[col-id="text"]`)?.innerText;
                    const urlPathArray = window.location.pathname?.split('/');
                    const requirementId = dataRow[1]?.querySelector(`[col-id="id"]`)?.innerText;

                    // customized requirement URL to open specific requirement in the new tab.
                    const urlPath = `${window.location.origin}/${urlPathArray[1]}/${urlPathArray[2]}/${urlPathArray[3]}/requirements/${requirementId ? requirementId : ''}`;

                    openDialogOSLC({
                        requirementId: requirementId ? requirementId : '',
                        titleLabel: identifier ? identifier : '',
                        title: titleText ? titleText : '',
                        sourceType: 'Requirement',
                        uri: urlPath,
                    });
                }
            );
        });
    }

    // Create link with valispace project
    const actionContainer = document.querySelector('.app-content-container')?.querySelector('.actions')
    // check the container is available
    if (actionContainer) {
        const projBtn = document.createElement('button');
        projBtn.className = "btn-wbe-project";
        //projBtn.className = "project-wbe-btn mat-focus-indicator mat-icon-button mat-button-base requirements ng-star-inserted";
        projBtn.setAttribute('_ngcontent-uhg-c302', '');
        projBtn.setAttribute('mat-icon-button', '');
        projBtn.setAttribute('traceLynxBtn1', '');
        projBtn.innerHTML = `
          <span class="mat-button-wrapper">${projectWBEIcon}</span>
          <span matripple class="mat-ripple mat-button-ripple mat-button-ripple-round"></span>
          <span class="mat-button-focus-overlay"></span>
        `;

        const projectWbeBtn = actionContainer.querySelector('[traceLynxBtn1]')
        const isAboutSection = window.location.pathname?.includes('/about');

        // only show the WBE icon on the About page for the create link with the Valispace project
        // if (isAboutSection) {
            if (!projectWbeBtn) actionContainer?.insertBefore(projBtn, actionContainer.firstChild);
        //}
        //else {
        //    const prjWbeIcon = actionContainer.querySelector('.project-wbe-btn')
        //    if (projectWbeBtn) actionContainer?.removeChild(prjWbeIcon);
        //}

        // Open traceLynx
        projBtn.addEventListener("click", function () {
            openDialogOSLC({
                titleLabel: '',
                title: '',
                sourceType: "Project",
                uri: window.location.href,
            })
        });
    };
});

myObserver.observe(document, {
    subtree: true,
    attributes: true,
});
