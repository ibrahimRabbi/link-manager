// const projectWBEIcon = `<svg aria-hidden="true" height="25" viewBox="4 4 16 16" version="1.1" width="25" data-view-component="true" class="octicon octicon-code UnderlineNav-octicon d-none d-sm-inline"><path fill="#7d8d91" fill-rule="evenodd" d="M11 17H7Q4.925 17 3.463 15.537Q2 14.075 2 12Q2 9.925 3.463 8.462Q4.925 7 7 7H11V9H7Q5.75 9 4.875 9.875Q4 10.75 4 12Q4 13.25 4.875 14.125Q5.75 15 7 15H11ZM8 13V11H16V13ZM13 17V15H17Q18.25 15 19.125 14.125Q20 13.25 20 12Q20 10.75 19.125 9.875Q18.25 9 17 9H13V7H17Q19.075 7 20.538 8.462Q22 9.925 22 12Q22 14.075 20.538 15.537Q19.075 17 17 17Z"/></svg>`

const projectWBEIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 160 160">
<defs>
  <style>
    .cls-1, .cls-2 {
      fill: #fff;
    }

    .cls-1 {
      fill-rule: evenodd;
    }
  </style>
</defs>
<path class="cls-1" d="M38,85.928L39.979,80,66.016,98.082l-1.974,5.933Z"/>
<path class="cls-1" d="M92.827,104.357L90.69,98.69l28.209-28.6,2.137,5.666Z"/>
<circle id="Ellipse_1_copy_2" data-name="Ellipse 1 copy 2" class="cls-2" cx="23.328" cy="73.359" r="19.984"/>
<path id="Ellipse_1_copy_4" data-name="Ellipse 1 copy 4" class="cls-1" d="M79.985,83.333A20.013,20.013,0,1,1,60,103.346,20,20,0,0,1,79.985,83.333Z"/>
<circle id="Ellipse_1_copy_3" data-name="Ellipse 1 copy 3" class="cls-2" cx="133.297" cy="63.359" r="19.985"/>
</svg>`;