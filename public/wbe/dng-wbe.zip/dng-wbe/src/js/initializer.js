const myObserver = new MutationObserver(function () {
    //Requirement list
    let requirement_list = document.getElementsByClassName("resourceRow");
    if (requirement_list.length > 0) {
        Array.from(requirement_list).map((req) => {
            if (!req.classList.contains("injected")) {
                req.classList.add("injected");
                let div = document.createElement("div");
                let tr = req.getElementsByTagName("tr");
                let btn = document.createElement("button");
                div.className = "mod-date gridCellWrapper";
                btn.className = "btn-wbe";
                btn.innerHTML = icon;
                div.appendChild(btn);
                tr[0]?.appendChild(div);
                btn.addEventListener("click", function () {
                    let title = req?.getElementsByClassName("name cellEditable");
                    let artifactUrl = req?.getAttribute("objectid");
                    let project = document?.getElementsByClassName(
                        "banner-title jazz-ui-PageTemplate-flexrow__size1 jazz-ui-PageTemplate_bannerMinWidth"
                    );

                    // check the artifact type column is available or not
                    const tableHeaderContainer = document.getElementById('com_ibm_rdm_web_grid_ViewHeader_0');
                    const isArtifactType = tableHeaderContainer?.textContent?.toLowerCase()?.includes('artifact')
                    // get artifact type from the table column
                    const artifactCell = req.querySelector('tr')?.childNodes[4];
                    const artifactType = artifactCell?.innerText?.trim()

                    openDialogOSLC({
                        uri: artifactUrl,
                        title: title[0]?.textContent,
                        sourceType: isArtifactType ? artifactType : 'Requirement',
                        project: project[0]?.title,
                    });
                });
            }
        });
    }

    //Requirement details
    const req_div = document?.getElementsByClassName("resource-actions");
    if (req_div.length > 0) {
        if (!req_div[0].classList.contains("injected")) {
            req_div[0].classList.add("injected");
            let btn = document.createElement("button");
            btn.className = "btn-wbe";
            btn.innerHTML = icon;
            let toolbarContainer = document?.getElementsByClassName(
                "buttonsAndToolbar ibmdl"
            );
            toolbarContainer[0]?.appendChild(btn);
            btn.addEventListener("click", function () {
                let title = document?.getElementsByClassName("resource-title");
                let project = document?.getElementsByClassName(
                    "banner-title jazz-ui-PageTemplate-flexrow__size1 jazz-ui-PageTemplate_bannerMinWidth"
                );

                let baseUrl = title[0]?.baseURI;
                if (baseUrl.includes("web#action")) {
                    baseUrl = baseUrl.replace("web#action", "web?action");
                }
                baseUrl = new URL(baseUrl);
                let searchParams = baseUrl.searchParams;
                let artifactUrl = searchParams.get("artifactURI");

                console.log("second function wbe btn: ",);
                console.log("uri", artifactUrl);
                console.log("title", title[0]?.title);
                console.log("project", project[0]?.title);
                openDialogOSLC({
                    uri: artifactUrl,
                    title: title[0]?.title,
                    sourceType: "Requirement",
                    project: project[0]?.title,
                });
            });
        }
    }
});

myObserver.observe(document, {
    subtree: true,
    attributes: true,
});
