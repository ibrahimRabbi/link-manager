const myObserver = new MutationObserver(function () {
    //Requirement list
    let requirement_list=document.getElementsByClassName("resourceRow");    
    if(requirement_list.length>0){
        Array.from(requirement_list).map(req => {
            if(!req.classList.contains("injected")){
                req.classList.add('injected');
                let div = document.createElement("div");
                let tr=req.getElementsByTagName("tr");
                let btn = document.createElement('button');
                div.className = "mod-date gridCellWrapper";
                btn.className = "btn-wbe";
                btn.innerHTML = icon;  
                div.appendChild(btn);               
                tr[0]?.appendChild(div);
                btn.addEventListener("click",
                function () {
                    let title=req?.getElementsByClassName("name cellEditable");
                    console.log(title);
                    let project=document?.getElementsByClassName("banner-title jazz-ui-PageTemplate-flexrow__size1 jazz-ui-PageTemplate_bannerMinWidth");
                    console.log("uri", title[0]?.baseURI)
                    console.log("title", title[0]?.textContent)
                    console.log("project", project[0]?.title)
                    openDialogOSLC({
                        uri: title[0]?.baseURI,
                        title: title[0]?.textContent,
                        sourceType: "Requirement",
                        project: project[0]?.title
                    })
                }
            );
            }
        });
    }

    //Requirement details
    const req_div=document?.getElementsByClassName("resource-actions")
    if (req_div.length>0) {
        if(!req_div[0].classList.contains("injected")){
            req_div[0].classList.add('injected');
            //let div = document.createElement('div');
            let btn = document.createElement('button');
            btn.className = "btn-wbe";            
            btn.innerHTML = icon; 
            //div.appendChild(btn);
            let toolbarContainer=document?.getElementsByClassName("buttonsAndToolbar ibmdl");
            toolbarContainer[0]?.appendChild(btn);            
            btn.addEventListener("click",
                function () {
                    let title=document?.getElementsByClassName("resource-title");
                    let project=document?.getElementsByClassName("banner-title jazz-ui-PageTemplate-flexrow__size1 jazz-ui-PageTemplate_bannerMinWidth");
                    console.log("uri", title[0]?.baseURI)
                    console.log("title", title[0]?.title)
                    console.log("project", project[0]?.title)
                    openDialogOSLC({
                        uri: title[0]?.baseURI,
                        title: title[0]?.title,
                        sourceType: "Requirement",
                        project: project[0]?.title
                    })
                }
            );
        }
    }
});

myObserver.observe(document, {
    subtree: true,
    attributes: true,
});
